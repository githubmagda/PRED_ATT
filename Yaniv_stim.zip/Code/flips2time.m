function t = flips2time(Params,f)
 t = f*Params.Display.flipInterval;
end