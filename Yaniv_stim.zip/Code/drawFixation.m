function drawFixation(Params)
Screen ('DrawDots', Params.w,Params.wCenter , angle2pix(Params.Display,Params.fixationSize), [255 0 0],[],2);
end