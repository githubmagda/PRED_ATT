function[] = sanjeevDemo()

% Clear the workspace and the screen
sca;
close all;
clearvars;

% VARIABLES
imageDur            = 0.5;
fixDur              = 1.0;
fixCrossLength      = 12;

% use eyelink?
useEyelink          = 0;
dummymode           = 0;

% Setup PTB with some default values
PsychDefaultSetup(2);

% Set the screen number to the external secondary monitor if there is one
% connected
screenNumber = max(Screen('Screens'));

% Define black, white and grey
white = WhiteIndex(screenNumber);
grey = white / 2;

% Skip sync tests for demo purposes only
Screen('Preference', 'SkipSyncTests', 2);

try
% Open the screen
[window, windowRect] = PsychImaging('OpenWindow', screenNumber, grey, [0 0 600 600], 32, 2,...
    [], [],  kPsychNeed32BPCFloat);

%--------------------
% Grating information
%--------------------

% Dimension of the region where will draw the grating in pixels
width   = windowRect(3); 
centerX = width/2;
height  = windowRect(4); 
centerY = height/2;
imageDim = 100;
imageRect = [imageDim, imageDim];

% fix cross
fixCrossColor       = [0, 0, 0, 0];
fixCrossLineWidth   = 4;
fixCrossArmLength   = 12;
xCoords             = [ width/2-fixCrossArmLength, width/2+fixCrossArmLength , width/2, width/2];
yCoords             = [ width/2, width/2, width/2-fixCrossArmLength, width/2+fixCrossArmLength]; %[0, 0, 0, 0];
allCoords           = [xCoords; yCoords];

% % images
% dog         = imread( 'LOAD/dog1.jpg', 'jpg');
% dog         = imresize( dog, 0.5);
% dog         = imresize( dog, [ imageDim, imageDim]); 
% dogTex      = Screen('MakeTexture', window, dog);

% Obvious Parameters
backgroundColorOffset       = [ 0 0 0 0];
radius                      = 50;                        % in pixels; creates circular mask 
contrastPreMultiplicator    = 1.0;

%%% GRATING 
% Spatial Frequency (Cycles Per Pixel)
% One Cycle = Grey-Black-Grey-White-Grey i.e. One Black and One White Lobe
numCycles           = 64;
freq                = numCycles / width;           
phase               = 70;

[gratingtex, gratingRect]   = CreateProceduralSineGrating(window, width, height, backgroundColorOffset, radius, contrastPreMultiplicator);

angleSet           = [0, 90];         % Inital angle of grating
contrast            = 1;

%% END GRATING PREP

% where will image appear (selected in trial)
offsetWidthSet = [ -imageDim, imageDim ];

% EYELINK
if useEyelink
    ete.fixPoliceX          = width/2;
    eye.fixPoliceY          = height/2;
    eye.fixPoliceRadius     = 30;
    eye.maxPoliceErrorTime  = .2;           % allow for blinks out of monitored area
    eye.policeEye           = 2;            % 1 = left, 2 = right;
    eye.fixPoliceOffset     = 100;
    eye.gazeRightBorder        = eye.fixPoliceX + eye.fixPoliceOffset;
    eye.gazeLeftBorder        = eye.fixPoliceX - eye.fixPoliceOffset;
    % name .edf file for this series
    edfFileName = strcat( 'Test.edf', num2str(1));
    
    % set Eyelink defaults
    el=EyelinkInitDefaults(window);

    % Initialization of the connection with the Eyelink Gazetracker.
    % exit program if this fails.
    if ~EyelinkInit(dummymode)
        fprintf('Eyelink Init aborted.\n');
        cleanup;  % cleanup function
        return;
    end
    
    % set specs for output in edf file
    Eyelink('command', 'link_sample_data = LEFT,RIGHT,GAZE,AREA');
    Eyelink('command', 'link_event_data = ');
    
    statusFile = Eyelink('Openfile', edfFileName);
    % send message to edf file
    Eyelink('Message', 'File_created: ', edfFileName);
    
    % STEP 4
    % Calibrate the eye tracker
    EyelinkDoTrackerSetup(el);
    
    % do a preseries check of calibration using drift correction
    EyelinkDoDriftCorrection(el);
    
    WaitSecs(0.5);
    Eyelink('StartRecording');
    WaitSecs(0.1);
end   
    
trialStart = GetSecs; % start timer for first trial

for i = 1:5

    % trial options
    select              = randi( 2,1);
    thisAngle           = angleSet( select);        % random selection of grating angle
    select              = randi(2,1);
    thisWidthOffset     = offsetWidthSet(select);   % randomly place on left or right 
    dstRect             = OffsetRect(windowRect, thisWidthOffset, 0); 
    
    Screen('DrawLines', window, allCoords, fixCrossLineWidth, fixCrossColor); 

    % Draw the grating with new angle to dstRect
    Screen('DrawTexture', window, gratingtex, [], dstRect, thisAngle, [], [], ...
        [], [], [], [phase+180, freq, contrast, 0]);
    
    % Flip to the screen
    [ vblImage] = Screen('Flip', window);
    
    if useEyelink
    % police eyes
        leftRight = 0; % monitor for central fixation, not saccade
        sanjeevMonitorFixation( p, imageDur, leftRight);
    else
        WaitSecs( imageDur);
    end
    
    % just fixation cross
    Screen('DrawLines', window, allCoords, fixCrossLineWidth, fixCrossColor);  
    
    % Flip to the screen
    [ vblFix] = Screen('Flip', window);
    
    if useEyelink
        % police eyes
        leftRight = 1;         % monitor for left/right saccade
        sanjeevMonitorFixation(p, fixDur, leftRight);
    else
        WaitSecs( fixDur);
    end
    
end

catch
    psychrethrow( psychlasterror);
    cleanup( useEyelink);    
end

% Wait for a button press to exit
KbCheck;

% Clear screen
cleanup(useEyelink)
end


function[] = cleanup(useEyelink)
sca;
ShowCursor;
if useEyelink
    Eyelink('Closefile');
    Eyelink('StopRecording');
    Eyelink('Shutdown');
end
end


%Published with MATLAB® R2015b